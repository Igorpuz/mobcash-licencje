#version 150

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec2 UV0;

out vec2 texCoord0;

uniform sampler2D Sampler0;

void main() {
    vec3 position = Position;
    vec2 uv = UV0;
    if (all(equal(textureSize(Sampler0, 0), ivec2(256)))) {
        ivec4 markerA = ivec4(round(texelFetch(Sampler0, ivec2(255, 255), 0) * 255.0));
        ivec4 markerB = ivec4(round(texelFetch(Sampler0, ivec2(254, 255), 0) * 255.0));
        if (all(equal(markerA, ivec4(17, 203, 91, 255))) &&
            all(equal(markerB, ivec4(219, 41, 173, 255)))) {
            vec2 corner = UV0 * 256.0 / vec2(176.0, 166.0);
            position.xy += corner * vec2(60.0, 74.0) - vec2(30.0);
            uv = corner * vec2(236.0, 240.0) / 256.0;
        }
    }

    gl_Position = ProjMat * ModelViewMat * vec4(position, 1.0);

    texCoord0 = uv;
}
