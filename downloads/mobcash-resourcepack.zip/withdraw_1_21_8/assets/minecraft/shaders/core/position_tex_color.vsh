#version 150

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
    float LineWidth;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec2 UV0;
in vec4 Color;

out vec2 texCoord0;
out vec4 vertexColor;

uniform sampler2D Sampler0;

void main() {
    vec3 position = Position;
    vec2 uv = UV0;
    if (all(equal(textureSize(Sampler0, 0), ivec2(256)))) {
        ivec4 markerA = ivec4(round(texelFetch(Sampler0, ivec2(255, 255), 0) * 255.0));
        ivec4 markerB = ivec4(round(texelFetch(Sampler0, ivec2(254, 255), 0) * 255.0));
        if (all(equal(markerA, ivec4(17, 203, 91, 255))) &&
            all(equal(markerB, ivec4(219, 41, 173, 255)))) {
            vec2 corner = UV0 * 256.0 / vec2(176.0, 166.0);
            position.xy += corner * vec2(60.0, 74.0) - vec2(30.0);
            uv = corner * vec2(236.0, 240.0) / 256.0;
        }
    }

    gl_Position = ProjMat * ModelViewMat * vec4(position, 1.0);

    texCoord0 = uv;
    vertexColor = Color;
}
