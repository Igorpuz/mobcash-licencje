#version 150

#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;
uniform float GameTime;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    // Reserved colors identify only MobCash withdrawal animation frames.
    ivec3 mc = ivec3(round(Color.rgb * 255.0));
    if (mc.r == 254 && mc.b == 220 && mc.g >= 0 && mc.g < 20) {
        int activeFrame = int(floor(GameTime * 24000.0 / 2.0)) % 20;
        if (mc.g != activeFrame) gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a) * texelFetch(Sampler2, UV2 / 16, 0);
    }
}
